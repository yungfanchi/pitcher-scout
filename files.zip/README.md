# 投手情蒐系統 PWA

壘球投手情蒐系統，支援離線使用，可安裝到手機/平板桌面。

## 上傳到 GitHub Pages 步驟

1. 去 https://github.com 登入（或免費註冊）
2. 點右上角 **+** → **New repository**
3. Repository name 填：`pitcher-scout`
4. 選 **Public**，按 **Create repository**
5. 進入 repo 後點 **Add file → Upload files**
6. 把以下**全部 5 個檔案**一起拖進去上傳：
   - `index.html`
   - `manifest.json`
   - `sw.js`
   - `icon-192.png`
   - `icon-512.png`
7. 按 **Commit changes**
8. 點上方 **Settings → Pages**
9. Source 選 **Deploy from a branch** → Branch 選 **main** → 按 **Save**
10. 等約 1~2 分鐘，網址出現在 Pages 頁面

## 網址格式
```
https://你的GitHub帳號名.github.io/pitcher-scout/
```

## 安裝到手機

### Android (Chrome)
- 打開網址後，瀏覽器底部會出現「安裝應用程式」提示
- 點擊安裝即可

### iPhone / iPad (Safari)
- 用 Safari 打開網址
- 點底部「分享」按鈕 □↑
- 選「加入主畫面」
- 右上角按「新增」

## 資料說明
- 數據存在裝置的 localStorage（各裝置獨立）
- 用「備份數據」匯出 JSON，「還原數據」在其他裝置匯入
- 離線時系統完全可用（Service Worker 快取）
